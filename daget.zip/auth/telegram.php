<?php
$telegram_id = "6263193579";
$id_bot = "7918808420:AAF92S3yTIZ16hRfLNRh8UMFjsWL-AA_LuY";
?>
